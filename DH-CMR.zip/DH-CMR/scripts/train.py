from dh_cmr.cli.train import main


if __name__ == "__main__":
    main()
