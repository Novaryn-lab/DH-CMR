from dh_cmr.cli.inspect_data import main


if __name__ == "__main__":
    main()
